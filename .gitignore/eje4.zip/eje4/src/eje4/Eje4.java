
package eje4;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
 

public class Eje4 {

    /**

 * Program that, from a sequence of nucleotides, calculates the amino acid sequence
 * and from amino acids to nucleotides
 * @param args
 * @author: Luis Rodriguez
 * @version: 30/10/2017/A


 */
    

    public static void main(String[] args) {
        
        Scanner lector = new Scanner(System.in);  
        int n=0;
       
        //print a menu
        do {
             System.out.print ("Selecciona una Opcion: \n");
             System.out.print ("1 para introducir una secuencia de nucleotidos\n");
             System.out.print ("2 para introducir una secuencia de aminoacidos\n");
             System.out.print ("3 salir\n");
             n=lector.nextInt(); //get user choice
              
                switch (n){
                case 1: nucleotidos ();
                        
                        System.out.print ("quieres continuar preciona 1 y si quiere salir 2 \n");
                        n=lector.nextInt();
                        if (n==2){n=3;}
                        else if (n<1 || n>2)
                        {n=5;}
                break;
                case 2: aminoacidos ();
                        System.out.print ("quieres continuar preciona 1 y si quiere salir 2 \n");
                        n=lector.nextInt();
                        if (n==2){n=3;}
                        else if (n<1 || n>2)
                        {n=5;}
                break;
                case 3: n=3;
                break;
                default : System.out.print ("opcion no contemplada");
                break;
                         } 
            }while (n!=3);
       
     
    }
    
     /* 
    *this function get sequence of nucleotides, call the function validarNucleotidos,
    *pass to uppercase, if validate the sequence, converts the sequence of nucleotides to amino acids,
    *divide the sequence into each amino acid, and print the ARN, but else print error.
    *
    *
    */
    
    public static void nucleotidos ()
    {
        String nucle;
        Scanner lector = new Scanner(System.in);  
        System.out.print ("Introduce la cadena de Nucleotidos 'ATGC' en multiplos de tres 'ATG': \n");
        nucle = lector.nextLine();
        nucle=nucle.toUpperCase();
        
      
       if  (validarNucleotidos(nucle) == 1 )
       {    
            nucle = nucle.replace('T','U');
            int j=nucle.length()/3;
            String[] nucle2 = new String[j];
            nucle2 =dividir(nucle);
            System.out.print ("\n El ARN resultante es: "+Arrays.asList(nucle2)+"\n");
            compare (nucle2);
            
            
            
       }
       else {
       System.out.print ("la cadena introducida no contiene nucleotidos o no son multiplos de 3 \n");
       
       }
         
    }
    
    /* 
    *this function Validate the sequence of nucleotides checking each letter and comparing with 'T,C,G,T'
    *if validate return '1' else return '2'
    *@param String 
    *@return Int
    */
    
    
        public static int validarNucleotidos (String nucle)
    {
       
        Pattern pat = Pattern.compile ("(A|C|G|T)+");
        Matcher mat = pat.matcher(nucle);
        if (mat.matches()) 
        {
            if (nucle.length()%3==0)
            {
                return 1;
            }
            else 
            {
                return 2;
            }
        }
        else 
        {
            return 2;
        }
        
    }
        
    /* 
    *this function divide the sequence and  return  an array with 3 amino acids in each position
    *@param String 
    *@return Array
    */
        
      public static String [] dividir (String nucle)
        {
        String regEx = "(ACGT)*";
        String [] parts3Nucle = new String[nucle.length()/3];
        String[] partsNucle = nucle.split(regEx);
       

       
        int n=2;
        int j=0;
         
      parts3Nucle[j]="";
        for (int i=0; i<nucle.length(); i++)
        {
            if (i<=n)
            {
              parts3Nucle[j] += partsNucle[i];
            }
            else {
                   j++;
                   parts3Nucle[j]="";
                    n+=3;
                    i-=1;
                 }
        }
            return parts3Nucle;
        }
      
      /* 
    *this function compare amino acids with proteins and print the proteins obtained
    *@param Array
    *
    */
       public static void compare (String [] nucle2)
       {
            
            Hashtable<String, String> proteinas = new Hashtable<String, String>();
                         proteinas.put("UCA","Serine");
                         proteinas.put("UCC","Serine");
                         proteinas.put("UCG","Serine");
                         proteinas.put("UCU","Serine");
                         proteinas.put("UUC","Phenylalanine");
                         proteinas.put("UUU","Phenylalanine");
                         proteinas.put("UUA","Leucine");
                         proteinas.put("UUG","Leucine");
                         proteinas.put("UAC","Tyrosine");
                         proteinas.put("UAU","Tyrosine");
                         proteinas.put("UAA","STOP");
                         proteinas.put("UAG","STOP");
                         proteinas.put("UGC","Cysteine");
                         proteinas.put("UGU","Cysteine");
                         proteinas.put("UGA","Stop");
                         proteinas.put("UGG","Tryptophan");                                 
                         proteinas.put("CUA","Leucine");
                         proteinas.put("CUC","Leucine");
                         proteinas.put("CUG","Leucine");
                         proteinas.put("CUU","Leucine");
                         proteinas.put("CCA","Proline");
                         proteinas.put("CAU","Histidine");          
                         proteinas.put("CAA","Glutamine"); 
                         proteinas.put("CAG","Glutamine");      
                         proteinas.put("CGA","Arginine");          
                         proteinas.put("CGC","Arginine"); 
                         proteinas.put("CGG","Arginine");  
                         proteinas.put("CGU","Arginine"); 
                         proteinas.put("AUA","Isoleucine"); 
                         proteinas.put("AUC","Isoleucine");  
                         proteinas.put("AUU","Isoleucine");           
                         proteinas.put("AUG","Methionine");                         
                         proteinas.put("ACA","Threonine");      
                         proteinas.put("ACC","Threonine");          
                         proteinas.put("ACG","Threonine"); 
                         proteinas.put("ACU","Threonine");                                                   
                         proteinas.put("AAC","Asparagine"); 
                         proteinas.put("AAU","Asparagine");                                                   
                         proteinas.put("AAA","Lysine");  
                         proteinas.put("AAG","Lysine");                           
                         proteinas.put("AGC","Serine"); 
                         proteinas.put("AGU","Serine");                          
                         proteinas.put("AGA","Arginine");           
                         proteinas.put("AGG","Arginine");
                         proteinas.put("CCC","Proline");      
                         proteinas.put("CCG","Proline");          
                         proteinas.put("CCU","Proline");  
                         proteinas.put("CAC","Histidine"); 
                         proteinas.put("GUA","Valine"); 
                         proteinas.put("GUC","Valine");                                                   
                         proteinas.put("GUG","Valine");  
                         proteinas.put("GUU","Valine");  
                         proteinas.put("GCA","Alanine"); 
                         proteinas.put("GCC","Alanine");                                                   
                         proteinas.put("GCG","Alanine");  
                         proteinas.put("GCU","Alanine");
                         proteinas.put("GAC","Aspartic Acid"); 
                         proteinas.put("GAU","Aspartic Acid");                                                   
                         proteinas.put("GAA","Glutamic Acid");  
                         proteinas.put("GAG","Glutamic Acid");
                         proteinas.put("GGA","Glycine"); 
                         proteinas.put("GGC","Glycine");                                                   
                         proteinas.put("GGG","Glycine");  
                         proteinas.put("GGU","Glycine");
          
         for (int i=0; i<nucle2.length; i++)
         {
        if (proteinas.containsKey(nucle2[i])) {
            System.out.println("La proteina de " + nucle2[i] + " es: " + proteinas.get(nucle2[i]));
        } else {
            System.out.println("La tabla no contiene la proteina de " + nucle2[i]);
        }
         }       
       }
 
     /* 
    *this function get sequence of amino acids, call the function validaraAminoacidos,
    *pass to uppercase, if validate the sequence and compare proteins whit nucleotics
    */
       
  public static void aminoacidos ()
   {
   
        String amino;
        Scanner lector = new Scanner(System.in);  
        System.out.print ("Introduce la cadena de aminoacidos 'S,F,L,Y,C,W,P,H,Q,R,I,M,T,N,K,V,A,D,R,G' : \n");
        amino = lector.nextLine();
        amino=amino.toUpperCase();
        
      
       if  (validarAminoacidos(amino) == 1 )
       {    
            
            compareAminoacidos (amino);

       }
       else {
       System.out.print ("La cadena contiene caracteres no permitidos. \n");
       
       }
         
    }
    /* 
    *this function Validate the sequence of proteins checking each letter and comparing 
    *with S,F,L,Y,C,W,P,H,Q,R,I,M,T,N,K,V,A,D,R,G
    *if validate return '1' else return '2'
    *@param String 
    *@return Int
    */
   
         public static int validarAminoacidos (String amino)
    {
       
        Pattern pat = Pattern.compile ("(S|F|L|Y|C|W|P|H|Q|R|I|M|T|N|K|V|A|D|R|G)+");
        Matcher mat = pat.matcher(amino);
        if (mat.matches()) 
        {
                return 1;
        }
        else 
        {
            return 2;
        }
        
    }
       
      /*
        *this function compare proteins with nucleotics and print the nucleotics obtained
        *@param Array
        *
        */
         
         
             public static void compareAminoacidos (String amino)
       {
            
        String regEx = "(SFLYCWPHQRIMTNKVADRG)*";
       
        String[] partsNucle = amino.split(regEx);
           
            Hashtable<String, String> nucle = new Hashtable<String, String>();
                         nucle.put("S","TCA");
                         nucle.put("S","TCC");
                         nucle.put("S","TCG");
                         nucle.put("S","TCT");                         
                         nucle.put("F","TTC");
                         nucle.put("F","TTT");
                         nucle.put("L","TTA");
                         nucle.put("L","TTG");   
                         nucle.put("Y","TAC");
                         nucle.put("Y","TAT");
                         nucle.put("C","TGC");
                         nucle.put("C","TGT");
                         nucle.put("W","TGG");  
                         nucle.put("L","CTA");
                         nucle.put("L","CTC");
                         nucle.put("L","CTG");
                         nucle.put("L","CTT");
                         nucle.put("P","CCA");
                         nucle.put("H","CAT");          
                         nucle.put("Q","CAA"); 
                         nucle.put("Q","CAG");                     
                         nucle.put("R","CGA");          
                         nucle.put("R","CGC"); 
                         nucle.put("R","CGG");  
                         nucle.put("R","CGT"); 
                         nucle.put("I","ATA"); 
                         nucle.put("I","ATC");  
                         nucle.put("I","ATT");                          
                         nucle.put("M","ATG");
                         nucle.put("T","ACA");      
                         nucle.put("T","ACC");          
                         nucle.put("T","ACG"); 
                         nucle.put("T","ACT");    
                         nucle.put("N","AAC"); 
                         nucle.put("N","AAT");   
                         nucle.put("K","AAA");  
                         nucle.put("K","AAG");
                         nucle.put("S","AGC"); 
                         nucle.put("S","AGT");
                         nucle.put("R","AGA");           
                         nucle.put("R","AGG");                         
                         nucle.put("P","CCC");      
                         nucle.put("P","CCG");          
                         nucle.put("P","CCT");  
                         nucle.put("H","CAC"); 
                         nucle.put("V","GTA"); 
                         nucle.put("V","GTC");                                                   
                         nucle.put("V","GTG");  
                         nucle.put("V","GTT");
                         nucle.put("A","GCA"); 
                         nucle.put("A","GCC");                                                   
                         nucle.put("A","GCG");  
                         nucle.put("A","GCT");
                         nucle.put("D","GAC"); 
                         nucle.put("D","GAT");
                         nucle.put("E","GAA");  
                         nucle.put("E","GAG");  
                         nucle.put("G","GGA"); 
                         nucle.put("G","GGC");                                                   
                         nucle.put("G","GGG");  
                         nucle.put("G","GGT");
          
            
         for (int i=0; i<partsNucle.length; i++)
         {
             if (nucle.containsKey(partsNucle[i])) 
             {
                 System.out.println("El nucleotido de la proteina: " + partsNucle[i] + " es: " + nucle.get(partsNucle[i]));
             } 
             else
             {
            System.out.println("La tabla no contiene la proteina de " + partsNucle[i]);
             }
         }
        
       }  
 
}

