package eje2;
import java.text.Normalizer;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Eje2 {

   
/**

 * program that we introduce a phrase and it shows us if it is palindromic or not
 * @param args
 * @author: Luis Rodriguez
 * @version: 30/10/2017/A


 */
    
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);  //create a lector of the class Scanner
        String palindroma;
       
        String palindromaInvertida;
        
         
        System.out.print ("Introduce la cadena: \n");
        palindroma = lector.nextLine(); // read the string
        palindroma= eliminarAcentos (palindroma);// call the function eliminaAcentos and safe in to String palindromaO
        StringBuilder builder=new StringBuilder(palindroma); 
        palindromaInvertida=builder.reverse().toString(); //call the function to reverse and save the result in to String PalindromaInvertida
            //
       
        if(palindroma.equals(palindromaInvertida)) //if PalindomaO its equals to palindromaInvertida Print "is palindrome" else print "is not palindome"
        {
             System.out.print ("La cadena es palindroma \n");
        }
        else 
        { 
            System.out.print ("no es palindroma \n");
        }
       
           
    }
    
    /*ejemplo palabras palindromas con caracteres especiales.
              A vella catalana la taca lleva
              A l'olla vota la tovallola
              Agrupeu, que purga
              Ca, por al co,lo:m?er! Temo home, tremolo. Clar? Opac?
    A posta, suscitem socis cit!a?ts està-tics i co.smèt:ics usats o pa
    */

    /* 
    *this function Pass to upper case the string, remove the special characters and @return the String
    *@param String 
    *@return String
    */

    public static String eliminarAcentos(String str) 
    {

        str=str.toUpperCase();
        str = str.replaceAll("[ -@]", "");
        str=Normalizer.normalize(str, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
        return str;
    }

}


